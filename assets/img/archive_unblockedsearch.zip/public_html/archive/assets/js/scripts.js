var myVar;

function onopen() {
myVar = setTimeout(showPage, 1500);
}

function showPage() {
document.getElementById("loading-page").style.display = "none";
document.getElementById("main-body").style.display = "block";
}

function unblock_skprt() {
    var url = document.getElementById("search-input").value;

    var alertvanished = document.createElement('div')
    alertvanished.style.background = '#00ff26';
    alertvanished.style.width = '100vw';
    alertvanished.style.height = '35px';
    var alerttxt = document.createElement('p')
    alerttxt.style.color = 'black';
    alerttxt.textContent = 'This window is HIDDEN from GoGuardian, so your teacher will NOT see this page!'
    alerttxt.style.fontFamily = 'Arial'
    alerttxt.style.fontSize = '20px'
    alerttxt.style.textAlign = 'center';
    alerttxt.style.padding = '5px 0px 0px 0px';

    var iframe = document.createElement('iframe')
    iframe.style.border = 'none';
    iframe.style.width = '100%';
    iframe.style.height = '96vh';
    iframe.style.margin = '0';
    iframe.src = url;



    var win = window.open("", "");
    win.document.title = "New Tab";
    win.document.body.appendChild(alertvanished);
    win.document.body.appendChild(iframe);
    alertvanished.appendChild(alerttxt);
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    win.document.body.appendChild(iframe);

}

function unblock_skprt_1v1lol() {

    var alertvanished = document.createElement('div')
    alertvanished.style.background = '#00ff26';
    alertvanished.style.width = '100vw';
    alertvanished.style.height = '35px';
    var alerttxt = document.createElement('p')
    alerttxt.style.color = 'black';
    alerttxt.textContent = 'This window is HIDDEN from GoGuardian, so your teacher will NOT see this page!'
    alerttxt.style.fontFamily = 'Arial'
    alerttxt.style.fontSize = '20px'
    alerttxt.style.textAlign = 'center';
    alerttxt.style.padding = '5px 0px 0px 0px';

    var iframe = document.createElement('iframe')
    iframe.style.border = 'none';
    iframe.style.width = '100%';
    iframe.style.height = '96vh';
    iframe.style.margin = '0';
    iframe.src = ("https://1v1.lol/");



    var win = window.open("", "");
    win.document.title = "New Tab";
    win.document.body.appendChild(alertvanished);
    win.document.body.appendChild(iframe);
    alertvanished.appendChild(alerttxt);
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    win.document.body.appendChild(iframe);

}

function unblock_skprt_retrobowl() {

    var alertvanished = document.createElement('div')
    alertvanished.style.background = '#00ff26';
    alertvanished.style.width = '100vw';
    alertvanished.style.height = '35px';
    var alerttxt = document.createElement('p')
    alerttxt.style.color = 'black';
    alerttxt.textContent = 'This window is HIDDEN from GoGuardian, so your teacher will NOT see this page!'
    alerttxt.style.fontFamily = 'Arial'
    alerttxt.style.fontSize = '20px'
    alerttxt.style.textAlign = 'center';
    alerttxt.style.padding = '5px 0px 0px 0px';

    var iframe = document.createElement('iframe')
    iframe.style.border = 'none';
    iframe.style.width = '100%';
    iframe.style.height = '96vh';
    iframe.style.margin = '0';
    iframe.src = ("https://cookieduck.com/retrobowl/");



    var win = window.open("", "");
    win.document.title = "New Tab";
    win.document.body.appendChild(alertvanished);
    win.document.body.appendChild(iframe);
    alertvanished.appendChild(alerttxt);
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    win.document.body.appendChild(iframe);

}

function unblock_skprt_shellshockers() {

    var alertvanished = document.createElement('div')
    alertvanished.style.background = '#00ff26';
    alertvanished.style.width = '100vw';
    alertvanished.style.height = '35px';
    var alerttxt = document.createElement('p')
    alerttxt.style.color = 'black';
    alerttxt.textContent = 'This window is HIDDEN from GoGuardian, so your teacher will NOT see this page!'
    alerttxt.style.fontFamily = 'Arial'
    alerttxt.style.fontSize = '20px'
    alerttxt.style.textAlign = 'center';
    alerttxt.style.padding = '5px 0px 0px 0px';

    var iframe = document.createElement('iframe')
    iframe.style.border = 'none';
    iframe.style.width = '100%';
    iframe.style.height = '96vh';
    iframe.style.margin = '0';
    iframe.src = ("https://games.noguardian.lol/embeds/shell-shock.html");



    var win = window.open("", "");
    win.document.title = "New Tab";
    win.document.body.appendChild(alertvanished);
    win.document.body.appendChild(iframe);
    alertvanished.appendChild(alerttxt);
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    win.document.body.appendChild(iframe);

}

function unblock_skprt_jatdtplays() {

    var alertvanished = document.createElement('div')
    alertvanished.style.background = '#00ff26';
    alertvanished.style.width = '100vw';
    alertvanished.style.height = '35px';
    var alerttxt = document.createElement('p')
    alerttxt.style.color = 'black';
    alerttxt.textContent = 'This window is HIDDEN from GoGuardian, so your teacher will NOT see this page!'
    alerttxt.style.fontFamily = 'Arial'
    alerttxt.style.fontSize = '20px'
    alerttxt.style.textAlign = 'center';
    alerttxt.style.padding = '5px 0px 0px 0px';

    var iframe = document.createElement('iframe')
    iframe.style.border = 'none';
    iframe.style.width = '100%';
    iframe.style.height = '96vh';
    iframe.style.margin = '0';
    iframe.src = ("https://jetztplay.de/");



    var win = window.open("", "");
    win.document.title = "New Tab";
    win.document.body.appendChild(alertvanished);
    win.document.body.appendChild(iframe);
    alertvanished.appendChild(alerttxt);
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    win.document.body.appendChild(iframe);

}



function unblock_skprt_roblox() {

    var alertvanished = document.createElement('div')
    alertvanished.style.background = '#00ff26';
    alertvanished.style.width = '100vw';
    alertvanished.style.height = '35px';
    var alerttxt = document.createElement('p')
    alerttxt.style.color = 'black';
    alerttxt.textContent = 'This window is HIDDEN from GoGuardian, so your teacher will NOT see this page!'
    alerttxt.style.fontFamily = 'Arial'
    alerttxt.style.fontSize = '20px'
    alerttxt.style.textAlign = 'center';
    alerttxt.style.padding = '5px 0px 0px 0px';

    var iframe = document.createElement('iframe')
    iframe.style.border = 'none';
    iframe.style.width = '100%';
    iframe.style.height = '96vh';
    iframe.style.margin = '0';
    iframe.src = ("https://acb.supertunnelrush.com/demo");



    var win = window.open("", "");
    win.document.title = "New Tab";
    win.document.body.appendChild(alertvanished);
    win.document.body.appendChild(iframe);
    alertvanished.appendChild(alerttxt);
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    win.document.body.appendChild(iframe);

}

function unblock_skprt_geodash() {

    var alertvanished = document.createElement('div')
    alertvanished.style.background = '#00ff26';
    alertvanished.style.width = '100vw';
    alertvanished.style.height = '35px';
    var alerttxt = document.createElement('p')
    alerttxt.style.color = 'black';
    alerttxt.textContent = 'This window is HIDDEN from GoGuardian, so your teacher will NOT see this page!'
    alerttxt.style.fontFamily = 'Arial'
    alerttxt.style.fontSize = '20px'
    alerttxt.style.textAlign = 'center';
    alerttxt.style.padding = '5px 0px 0px 0px';

    var iframe = document.createElement('iframe')
    iframe.style.border = 'none';
    iframe.style.width = '100%';
    iframe.style.height = '96vh';
    iframe.style.margin = '0';
    iframe.src = ("https://scratch.mit.edu/projects/105500895/embed");



    var win = window.open("", "");
    win.document.title = "New Tab";
    win.document.body.appendChild(alertvanished);
    win.document.body.appendChild(iframe);
    alertvanished.appendChild(alerttxt);
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    win.document.body.appendChild(iframe);

}

function unblock_skprt_slope() {

    var alertvanished = document.createElement('div')
    alertvanished.style.background = '#00ff26';
    alertvanished.style.width = '100vw';
    alertvanished.style.height = '35px';
    var alerttxt = document.createElement('p')
    alerttxt.style.color = 'black';
    alerttxt.textContent = 'This window is HIDDEN from GoGuardian, so your teacher will NOT see this page!'
    alerttxt.style.fontFamily = 'Arial'
    alerttxt.style.fontSize = '20px'
    alerttxt.style.textAlign = 'center';
    alerttxt.style.padding = '5px 0px 0px 0px';

    var iframe = document.createElement('iframe')
    iframe.style.border = 'none';
    iframe.style.width = '100%';
    iframe.style.height = '96vh';
    iframe.style.margin = '0';
    iframe.src = ("https://kdata1.com/2020/05/slope/");



    var win = window.open("", "");
    win.document.title = "New Tab";
    win.document.body.appendChild(alertvanished);
    win.document.body.appendChild(iframe);
    alertvanished.appendChild(alerttxt);
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    win.document.body.appendChild(iframe);

}

function unblock_skprt_cookieclicker() {

    var alertvanished = document.createElement('div')
    alertvanished.style.background = '#00ff26';
    alertvanished.style.width = '100vw';
    alertvanished.style.height = '35px';
    var alerttxt = document.createElement('p')
    alerttxt.style.color = 'black';
    alerttxt.textContent = 'This window is HIDDEN from GoGuardian, so your teacher will NOT see this page!'
    alerttxt.style.fontFamily = 'Arial'
    alerttxt.style.fontSize = '20px'
    alerttxt.style.textAlign = 'center';
    alerttxt.style.padding = '5px 0px 0px 0px';

    var iframe = document.createElement('iframe')
    iframe.style.border = 'none';
    iframe.style.width = '100%';
    iframe.style.height = '96vh';
    iframe.style.margin = '0';
    iframe.src = ("https://games-online.io/game/cake-maker/");



    var win = window.open("", "");
    win.document.title = "New Tab";
    win.document.body.appendChild(alertvanished);
    win.document.body.appendChild(iframe);
    alertvanished.appendChild(alerttxt);
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    win.document.body.appendChild(iframe);

}

function unblock_skprt_fnaf() {

    var alertvanished = document.createElement('div')
    alertvanished.style.background = '#00ff26';
    alertvanished.style.width = '100vw';
    alertvanished.style.height = '35px';
    var alerttxt = document.createElement('p')
    alerttxt.style.color = 'black';
    alerttxt.textContent = 'This window is HIDDEN from GoGuardian, so your teacher will NOT see this page!'
    alerttxt.style.fontFamily = 'Arial'
    alerttxt.style.fontSize = '20px'
    alerttxt.style.textAlign = 'center';
    alerttxt.style.padding = '5px 0px 0px 0px';

    var iframe = document.createElement('iframe')
    iframe.style.border = 'none';
    iframe.style.width = '100%';
    iframe.style.height = '96vh';
    iframe.style.margin = '0';
    iframe.src = ("https://run3.io/popgame/fnaf/fnaf1/");



    var win = window.open("", "");
    win.document.title = "New Tab";
    win.document.body.appendChild(alertvanished);
    win.document.body.appendChild(iframe);
    alertvanished.appendChild(alerttxt);
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    win.document.body.appendChild(iframe);

}
