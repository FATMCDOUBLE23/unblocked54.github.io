//*Loading page*//
//*Loading page*//
//*Loading page*//

var myVar;

function onopen() {
myVar = setTimeout(showPage, 1000);
}

function showPage() {
document.getElementById("loading-page").style.display = "none";
document.getElementById("main-body").style.display = "block";
}


//*Unblock script [SEARCH]*//
//*Unblock script [SEARCH]*//
//*Unblock script [SEARCH]*//

function vanish_skprt() {
    var alertvanished = document.createElement('div')
    alertvanished.style.background = '#00ff26';
    alertvanished.style.width = '100vw';
    alertvanished.style.height = '35px';
    var alerttxt = document.createElement('p')
    alerttxt.style.color = 'black';
    alerttxt.textContent = 'This window is HIDDEN from GoGuardian, so your teacher will NOT see this page!'
    alerttxt.style.fontFamily = 'Arial'
    alerttxt.style.fontSize = '20px'
    alerttxt.style.textAlign = 'center';
    alerttxt.style.padding = '5px 0px 0px 0px';
    var iframe = document.createElement('iframe')
    iframe.style.border = 'none';
    iframe.style.width = '100vw';
    iframe.style.height = '100vh';
    iframe.style.margin = '0';
    iframe.src = ("https://games.noguardian.lol")



    var win = window.open("", "");
    win.document.title = "New Tab";
    win
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    win.document.body.appendChild(alertvanished);
    win.document.body.appendChild(iframe);
    alertvanished.appendChild(alerttxt);

    var interval = setInterval(function() {
        if (win.closed) {
            clearInterval(interval);
            win = undefined;
        }
    }, 500);
}

//* Drop down show *//
//* Drop down show *//
//* Drop down show *//
function open_categry_menu() {
  document.getElementById("categories-menu-jsgbid").classList.toggle("show-menu");
}

window.onclick = function(event) {
  if (!event.target.matches('#game-categories-menu')) {
    var dropdowns = document.getElementsByClassName("categories-menu");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show-menu')) {
        openDropdown.classList.remove('show-menu');
      }
    }
  }
}


//*Console logs*//
//*Console logs*//
//*Console logs*//

console.log("Unblocked Games Ultimate")
console.log("By: MousyMichael -> mousymichael.xyz")
console.log("hello clinton public schools administrators :nerd:");
