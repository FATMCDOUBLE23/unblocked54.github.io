var myVar;

function onopen() {
myVar = setTimeout(showPage, 1800);
}

function showPage() {
document.getElementById("loading-page").style.display = "none";
document.getElementById("main-body").style.display = "block";
}

function unblock_skprt() {
    var website = document.getElementById("unblock-source").value;
    var iframe = document.createElement('iframe')
    iframe.style.border = 'none';
    iframe.style.width = '100%';
    iframe.style.height = '100vh';
    iframe.style.margin = '0';
    iframe.src = website;



    var win = window.open("", "");
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    win.document.body.appendChild(iframe);

    var interval = setInterval(function() {
        if (win.closed) {
            clearInterval(interval);
            win = undefined;
        }
    }, 500);
}


console.log("| UnblockedSearch | Unblock websites in school | ");
